#ifndef __WGS84_H
#define __WGS84_H
#include <stdbool.h>
/*
 pi: 圆周率。
 a: 卫星椭球坐标投影到平面地图坐标系的投影因子。
 ee: 椭球的偏心率。
 x_pi: 圆周率转换量。
*/
 bool outOfChina(double lat, double lon);
double transformLat(double x, double y);
 double transformLon(double x, double y);
void WGS84toGCJ02(double wgLat, double wgLon, double *gcjLat, double *gcjLon);
void WGS84toBD09(double wgLat, double wgLon, double *bdLat, double *bdLon);

#endif

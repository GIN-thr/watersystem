#ifndef __GPS_H
#define __GPS_H

struct GGPS_DATA
{
    char GNSSrunstatus[2];//GNSS????:0 = GNSS??,1 = GNSS??
    char Fixstatus[2];//????:0 = ?????,1 = ????
    char UTCdatetime[19];//UTC date & Time  GPS????????????(UTC)??
    char latitude[11];//Latitude  γ��
    char logitude[12];//Longitude  ����
    char altitude[9];//MSL Altitude  MSL??
    char speedOTG[7];//Speed Over Ground  ????
    char course[7];//Course Over Ground  ????
    char fixmode[2];//Fix Mode  ????
    char Reserved1[2];//Reserved1  ??1
    char HDOP[5];//HDOP  ??????
    char PDOP[5];//PDOP  ????????
    char VDOP[5];//VDOP  ??????
    char Reserved2[2];//Reserved2
    char satellitesinview[3];//GPS Satellites in View  ???GPS??
    char GNSSsatellitesused[3];//GNSS Satellites Used  GNSS????
    char GLONASSsatellitesused[3];//GLONASS Satellites in View  ???????????(GLONASS)??
    char Reserved3[2];//Reserved3  ??1
    char CN0max[3];//C/N0 max
    char HPA[7];//HPA  ??????
    char VPA[7];//VPA
};


typedef struct {
     double latitude[9];//Latitude  γ��
    double logitude[12];//Longitude  ����
} MyStruct;


void uart2_receiver_handle(void);
void G4_Publish(void);
void G4_Open(void);
char G_Publish_Aliyun(void);
void Alyun(void);
void ThingsCloud(void);
void GPS_CGNSINF_Analyze(char *origin,struct GGPS_DATA *gpsdata);
void G4_inquire(void);
void NowWGS84(void);
void ll(void);
#endif

#ifndef __4G_H
#define __4G_H


void uart2_receiver_handle(void);
void G4_Publish(void);
void G4_Open(void);
char G_Publish_Aliyun(void);
void Alyun(void);
#endif



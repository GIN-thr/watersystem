/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stdio.h"
#include "lcd.h"
#include "lcd_init.h"
#include "delay.h"
#include "ds18b20.h"
#include "GPS.h"
#include "pic.h"
char response[256];
extern unsigned char receive_data[];  
struct GGPS_DATA GPS_DATA;		
extern char str[];
//
#include "WGS84.h"
double	lon=0;
	double	lonn=0;
	double	lat=0;
	double	latt=0;
//#include "bsp_usart2.h"
uint16_t count = 0;
uint16_t length = 0;
char rdata[10]={0};
char lcd[50] = {0};
uint16_t adc1 = 0;
uint16_t adcx;
	float temps = 0;;
uint16_t  counts = 0;
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

void HAL_Delay_us(uint32_t nus) //us??
{
HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq()/1000000);
HAL_Delay(nus-1);
HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq()/1000);
}
//�ض���print����
int fputc(int ch, FILE *f) 
{ 
	HAL_UART_Transmit(&huart1, (uint8_t *)&ch,1, 50);
	HAL_UART_Transmit(&huart3, (uint8_t *)&ch,1, 50);
//	while((USART1->SR&0X40)==0); 
//	USART1->DR = (char) ch; 
	return ch; 
}
uint16_t Dt = 0;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
//void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)
//	{
//		count++;
//	}

//	4g���Ӻ���
void send_at_command(const char *command, char *response, uint16_t response_size)
{
    memset(response, 0, response_size);

    // ??AT??
    HAL_StatusTypeDef status = HAL_UART_Transmit(&huart3, (uint8_t *)command, strlen(command), HAL_MAX_DELAY);
    
//	printf("%s",status);
	if (status == HAL_OK)
    {
        printf("SentOK: %s\r\n", command);
    }
    else
    {
        printf("Failed to send: %s\r\n", command);
    }

    // ????
    status = HAL_UART_Receive(&huart3, (uint8_t *)response, response_size - 1, 5000);
		printf("%s",response);
//    if (status == HAL_OK)
//    {
//        printf("Received: %s\r\n", response);
//    }
//    else if (status == HAL_TIMEOUT)
//    {
//        printf("No response received within timeout.\r\n");
//    }
//    else
//    {
//        printf("Error receiving response: %d\r\n", status);
//    }
}
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
volatile uint32_t time = 0; // ms ��ʱ���� 

////�������


 
GPIO_InitTypeDef  GPIO_InitStructure; 
unsigned char AD_CHANNEL=0;


float TDS=0.0,TDS_voltage;
float TDS_value=0.0,voltage_value;
float compensationCoefficient=1.0;//�¶�У׼ϵ��
float compensationVolatge;
float kValue=1.67;
float TEMP_Value=0.0;
float averageVoltage=0;

char  TEMP_Buff[5];   //�¶ȴ������
char  TDS_Buff[6];   //TDS�������


extern  u8 SET_Flag,SET_Count; //���ñ�־λ
extern u8 Warning_flag;
u8 Warning_count=0;
uint8_t temp = 0;
float pH = 0;
float conductivity = 0;
int flag_p =0;
int flag_m = 0;
//void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
//{
//	flag_p++;
//	if(flag_p>5000)
//	{
//		flag_p = 0;
//		flag_m = 1;
//	}
//}
//�¶Ȳɼ�
void TEMP_Value_Conversion()
{
				
	temp = ds18b20_get_temperature()/10;;
		sprintf(lcd,":%d",temp);
	
		LCD_ShowString(92,170,(const u8 *)lcd,BLACK,WHITE,16,0);
	LCD_ShowChinese(120,170,"��",BLACK,WHITE,16,0);
	   if(temp>25)
			{
				HAL_TIM_PWM_Start(&htim3,TIM_CHANNEL_4);
			}else{
				HAL_TIM_PWM_Stop(&htim3,TIM_CHANNEL_4);
			}
}
/**************TDSֵ�ɼ�����***************/
void TDS_Value_Conversion()
{
	  u32 ad=0;
	  u8 i;
ds18b20_init();	

	  float compensationCoefficient;
	  float compensationVolatge;
	  float temperature= ds18b20_get_temperature()/10;;//�����¶���25�ȣ������¶Ȳ����������18B20����ɼ��¶Ⱥ󣬸�������¶�ֵ
	  
		
	  ad=0;
	  for(i=0;i<50;i++)//��ȡ50�ε�AD��ֵȡ��ƽ������Ϊ׼ȷ	
		{
			HAL_ADC_Start(&hadc1);
			while(!HAL_ADC_GetState(&hadc1));//ת��������־λ
			
			ad=ad+HAL_ADC_GetValue(&hadc1);//�������һ��ADCx�������ת�����		
		}
		ad=ad/50;
	//ADC_ConvertedValueLocal[0]=(float)ad/4096*3.3; //ADת��
	 averageVoltage	=(float)ad/4096*3.3; //ADת��
//		printf("averageVoltage=%0.3f\n",averageVoltage);
	// averageVoltage = getMedianNum(analogBufferTemp, SCOUNT) * (float)VREF / 1024.0; // read the analog value more stable by the median filtering algorithm, and convert to voltage value
	 compensationCoefficient = 1.0 + 0.02 * (temperature - 25.0); //temperature compensation formula: fFinalResult(25^C) = fFinalResult(current)/(1.0+0.02*(fTP-25.0));
   compensationVolatge = averageVoltage / compensationCoefficient; //temperature compensation
   TDS_value = (133.42 * compensationVolatge * compensationVolatge * compensationVolatge - 255.86 * compensationVolatge * compensationVolatge + 857.39 * compensationVolatge) * 0.5; //convert voltage value to tds value	

    sprintf(lcd,":%0.2f",TDS_value);
		LCD_ShowString(104,250,(const u8 *)lcd,BLACK,WHITE,16,0);
		
		
		
		
	/*	
	compensationCoefficient=1.0+0.02*((TEMP_Value/10)-25.0); 
	compensationVolatge=ADC_ConvertedValueLocal[1]/compensationCoefficient;
	if((ADC_ConvertedValueLocal[2]>=0)&&(ADC_ConvertedValueLocal[1]<0.1))
	{compensationVolatge=0;}
	TDS_value=(133.42*compensationVolatge*compensationVolatge*compensationVolatge - 
	255.86*compensationVolatge*compensationVolatge + 857.39*compensationVolatge)*0.5*kValue;
	
	  if((TDS_value<=0)){TDS_value=111;}
		if((TDS_value>1400)){TDS_value=1400;}	
*/
	
	/*��ʾEC*/
	TDS_Buff[0]=(int)(TDS_value)/1000+'0';
	TDS_Buff[1]=(int)(TDS_value)%1000/100+'0';
	TDS_Buff[2]=(int)(TDS_value*100)%100/10+'0';	
	TDS_Buff[3]=(int)(TDS_value*100)%10+'0';

}







//���ǶȲɼ�����
uint8_t Get_Adc_Averages(uint8_t times)
{
	u32 temp_val=0;
	uint8_t t;
	HAL_ADC_Start(&hadc2);
		sprintf(lcd,":%0.2f NTU",-865.68*(HAL_ADC_GetValue(&hadc2)*3.3/4096)+3291.3);
//		LCD_ShowChinese(60,90,"���Ƕ�",BLACK,WHITE,16,0);
	conductivity = -865.68*(HAL_ADC_GetValue(&hadc2)*3.3/4096)+3291.3;

//						LCD_ShowString(108,90,(const u8 *)lcd,BLACK,WHITE,16,0);
	for(t=0;t<times;t++)
	{
		temp_val+=HAL_ADC_GetValue(&hadc2);
		
		//SYSTICK_DelayMs(5);	 
	}
	return temp_val/times;
}

#define median_filtering_length 3

uint16_t median_filtering(){
	
  int senseV[median_filtering_length];

  for(int i = 0; i < median_filtering_length; i++){
    senseV[i] = Get_Adc_Averages(2);

  }

  for(int i = 0; i < median_filtering_length; i++ ){
    for(int k = i; k <median_filtering_length; k++ ){
      if(senseV[i] > senseV[k]){
          int tmp = senseV[i];
          senseV[i] = senseV[k];
          senseV[k] = tmp;
      }
    }  
  }
	sprintf(lcd,"deep=%0.2fcm", -865.68*(senseV[median_filtering_length/2]*2*3.3/4096)+3291.3);
						LCD_ShowString(60,300,(const u8 *)lcd,RED,WHITE,16,0);
  return senseV[median_filtering_length/2];
}

// ADC1_CH9 PH
void readPH_ADC1_CH9(void) {
//	ADC_Key_GET();
	  ds18b20_init();	
	  float tmpetValue= ds18b20_get_temperature()/10;;
    uint32_t adcValue = HAL_ADC_GetValue(&hadc1); // ??ADC1??2??
    float voltage = (float)adcValue * 3.3/4096; // ?ADC???????
	
//	  printf("777=%0.2f",voltage);
	
//     pH = -5.964 * voltage + 22.555; // ??PH?????????????????pH?
//	PH_Value = -5.9647*PH_Value+22.255;                        //ͨ����ʽת����PHֵ

//	   if( temp > 42 ) 
//		 {adcValue+= 5;     } //�¶Ȳ���
//		else if(temp > 28)
//		 {
//     adcValue += 5*(temp - 28)/14;
//   }
//     pH=(float)adcValue*(3.3/4096); //ת��Ϊ��ѹֵ
		pH = 3.5*voltage-1;   //����PH
//	 pH =  -5.7541*voltage+16.654;
//	 printf("PH=%0.2f",pH);

   if(pH<=0) pH = 0;                            //PHֵС��0 ����Ϊ0
    else if(pH>=14) pH = 14;                    //PHֵ����14 ����Ϊ14
		
	sprintf(lcd,":%0.3f",pH);
  LCD_ShowString(104,210,(const u8 *)lcd,BLACK,WHITE,16,0);
    
}
void hal_delay_us(uint32_t nus){ 
HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq() / 1000000); 
HAL_Delay(nus - 1); 
HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq() / 1000); 
}
//��Ȳ�������
void sr04(void){
        HAL_Delay(1000);
        HAL_GPIO_WritePin(GPIOB,  GPIO_PIN_6, 0);
        hal_delay_us(15);
        HAL_GPIO_WritePin(GPIOB,  GPIO_PIN_6, 1);
        hal_delay_us(15);
        HAL_GPIO_WritePin(GPIOB,  GPIO_PIN_6, 0);
      //  hal_delay_us(10);
        
        while(HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_5) == 0){
            ;
        }
        __HAL_TIM_SET_COUNTER(&htim2, 0);    
        HAL_TIM_Base_Start(&htim2);
        while(HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_5) == 1){
            ;
        }
       Dt = __HAL_TIM_GET_COUNTER(&htim2)*17/1000;
					
//       printf("%dmm",Dt*17/1000);
						sprintf(lcd,":%d mm",17-Dt);
						LCD_ShowString(92,130,(const u8 *)lcd,BLACK,WHITE,16,0);
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	flag_p++;
	if(flag_p>60000)
	{

//		send_at_command("AT\r", response, sizeof(response));//ȷ�Ͽ���������Ӧ������
//					send_at_command("ATE0\r", response, sizeof(response));//�رջ���
//					send_at_command("AT+ICCID\r", response, sizeof(response));//ȷ��SIM����ã���ѯsim��CCID
//					send_at_command("AT+CGATT?\r", response, sizeof(response));//ȷ���Ƿ񡤸�������
//					send_at_command("AT+CSTT="","",""\r", response, sizeof(response));//����APN
//					send_at_command("AT+CIICR\r", response, sizeof(response));//��������
//					send_at_command("AT+CIFSR\r", response, sizeof(response));//��ѯIP
//					send_at_command("AT+CPIN?", response, sizeof(response));//
//					send_at_command("AT+MCONFIG=c571f83b-e395-4ae2-a8d4-c1589cab57a1,qys,qys\r", response, sizeof(response));
//					send_at_command("AT+MIPSTART=118.24.230.64,1883\r", response, sizeof(response));
//					send_at_command("AT+MCONNECT=1,120\r", response, sizeof(response));
//					sprintf(lcd,"AT+MPUB=pubtopic1,0,0,'{\\22temp\\22:\\22%d\\22\\22ph\\22:\\22%0.2f\\22\\22muddy\\22:\\22%0.2f\\22\\22conductivity\\22:\\22%0.2f\\22\\22deep\\22:\\22%d\\22}'\r",temp,pH,conductivity,TDS_value,17-Dt);
//					send_at_command(lcd, response, sizeof(response));
				flag_p = 0;
		flag_m =1;
	}
}
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	if(rdata[0]=='1')
	{
		
		HAL_UART_Transmit(&huart1, (const uint8_t *)"111", 3, 500);
		HAL_TIM_PWM_Start(&htim3,TIM_CHANNEL_4);
	}
	HAL_UART_Receive_IT(&huart1,( uint8_t *)rdata, 10);
}




/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM3_Init();
  MX_TIM4_Init();
  MX_USART1_UART_Init();
  MX_TIM2_Init();
  MX_ADC2_Init();
  MX_ADC1_Init();
  MX_TIM1_Init();
  MX_USART3_UART_Init();
  /* USER CODE BEGIN 2 */
		
	  int len = 0;
		
ds18b20_init();	
HAL_UART_Receive_IT(&huart3,( uint8_t *)rdata, 10);
		float ad_v = 2.0;
		uint16_t  temperature;
		LCD_Init();
LCD_GPIO_Init();
uint16_t x = 2;//x,y��ʾ����
uint16_t y = 4;
uint8_t num = 'h';//num Ҫ��ʾ���ַ�
uint16_t fc = YELLOW ;//fc �ֵ���ɫ
uint16_t bc = 0;//bc �ֵı���ɫ
uint8_t sizey = 0;//sizey �ֺ�
uint8_t mode = 0;//mode:  0�ǵ���ģʽ  1����ģʽ
		uint8_t i,j;
	float t=0;
		
ds18b20_init();

//	delay_init();
//	LED_Init();//LED��ʼ��
	LCD_Init();//LCD��ʼ��
	LCD_Fill(0,0,LCD_W,LCD_H,WHITE);
	HAL_TIM_Base_Start_IT(&htim1);
	HAL_ADC_Init(&hadc2);


  printf("Initialization Completed Successfully\r\n");
	

int num1 =0;

//    LCD_Fill(0,0,240,320,BLUE);
		LCD_ShowChinese(70,20,"ˮ",BLACK,WHITE,24,0);
		LCD_ShowChinese(110,20,"��",BLACK,WHITE,24,0);
		LCD_ShowChinese(150,20,"��",BLACK,WHITE,24,0);
		LCD_ShowChinese(190,20,"��",BLACK,WHITE,24,0);
		LCD_ShowPicture(20,10,40,40,gImage_2);
		LCD_ShowChinese(60,170,"�¶�",BLACK,WHITE,16,0);
		LCD_ShowPicture(20,80,35,30,gImage_xx);
			LCD_ShowChinese(60,130,"���",BLACK,WHITE,16,0);
		LCD_ShowPicture(20,120,35,35,gImage_xx1);
			 	LCD_ShowChinese(60,250,"������",BLACK,WHITE,16,0);
		LCD_ShowPicture(20,160,35,35,gImage_xx2);
			LCD_ShowChinese(60,90,"���Ƕ�",BLACK,WHITE,16,0);
		LCD_ShowPicture(20,200,35,32,gImage_xx5);
		LCD_ShowChinese(60,210,"����",BLACK,WHITE,16,0);
		;LCD_ShowPicture(20,240,35,32,gImage_xx4);
		
		uint16_t wd = 3;
		HAL_TIM_Base_Start(&htim1);
//    send_at_command("AT\r", response, sizeof(response));//ȷ�Ͽ���������Ӧ������
//			send_at_command("ATE0\r", response, sizeof(response));//�رջ���
//			send_at_command("AT+ICCID\r", response, sizeof(response));//ȷ��SIM����ã���ѯsim��CCID
//			send_at_command("AT+CGATT?\r", response, sizeof(response));//ȷ���Ƿ񡤸�������
//			send_at_command("AT+CSTT="","",""\r", response, sizeof(response));//����APN
//			send_at_command("AT+CIICR\r", response, sizeof(response));//��������
//		  send_at_command("AT+CIFSR\r", response, sizeof(response));//��ѯIP
//			send_at_command("AT+CPIN?", response, sizeof(response));//
//		LCD_ShowChinese(20,60,"��",BLACK,WHITE,24,0);
//	LED=0;
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
		
			HAL_ADC_Start(&hadc2);
	  conductivity = -865.68*(HAL_ADC_GetValue(&hadc2)*3.3/4096)+3291.3;
		sprintf(lcd,":%0.2f NTU",-865.68*(HAL_ADC_GetValue(&hadc2)*3.3/4096)+3291.3);
		printf("conductivity=%0.2f",-865.68*(HAL_ADC_GetValue(&hadc2)*3.3/4096)+3291.3);
		LCD_ShowString(108,90,(const u8 *)lcd,BLACK,WHITE,16,0);
		readPH_ADC1_CH9();//ph
		TEMP_Value_Conversion();//�¶�
//     Get_Adc_Averages();//���Ƕ�

//			NowWGS84();
			TDS_Value_Conversion();//TDS
		  sr04();//���

		//4gͨѶ
//		send_at_command("AT\r", response, sizeof(response));//ȷ�Ͽ���������Ӧ������
//					send_at_command("ATE0\r", response, sizeof(response));//�رջ���
//		HAL_Delay(1000);
//					send_at_command("AT+ICCID\r", response, sizeof(response));//ȷ��SIM����ã���ѯsim��CCID
//		HAL_Delay(1000);
//					send_at_command("AT+CGATT?\r", response, sizeof(response));//ȷ���Ƿ񡤸�������
//					
//					send_at_command("AT+CSTT="","",""\r", response, sizeof(response));//����APN
//				
//					send_at_command("AT+CIICR\r", response, sizeof(response));//��������
//			
//					send_at_command("AT+CIFSR\r", response, sizeof(response));//��ѯIP
//					
//					send_at_command("AT+CPIN?", response, sizeof(response));//
//	
//					send_at_command("AT+MCONFIG=c571f83b-e395-4ae2-a8d4-c1589cab57a1,qys,qys\r", response, sizeof(response));
//				
//					send_at_command("AT+MIPSTART=118.24.230.64,1883\r", response, sizeof(response));
//	
//					send_at_command("AT+MCONNECT=1,120\r", response, sizeof(response));
//		
//		sprintf(lcd,"AT+MPUB=pubtopic1,0,0,'%ds%0.2fs%0.2fs%0.2fs%d'\r",temp,pH,conductivity,TDS_value,17-Dt);
//						send_at_command(lcd, response, sizeof(response));
						//send_at_command("AT+MPUB=pubtopic1,0,0,'\\22temp\\22:\\22%d\\22\\22ph\\22:\\22%0.2f\\22\\22muddy\\22:\\22%0.2f\\22\\22conductivity\\22:\\22%0.2f\\22\\22deep\\22:\\22%d\\22'\r", response, sizeof(response));
		  switch(flag_m)
			{
				case 1:
					send_at_command("AT\r", response, sizeof(response));//ȷ�Ͽ���������Ӧ������
					send_at_command("ATE0\r", response, sizeof(response));//�رջ���
					send_at_command("AT+ICCID\r", response, sizeof(response));//ȷ��SIM����ã���ѯsim��CCID
					send_at_command("AT+CGATT?\r", response, sizeof(response));//ȷ���Ƿ񡤸�������
					send_at_command("AT+CSTT="","",""\r", response, sizeof(response));//����APN
					send_at_command("AT+CIICR\r", response, sizeof(response));//��������
					send_at_command("AT+CIFSR\r", response, sizeof(response));//��ѯIP
					send_at_command("AT+CPIN?", response, sizeof(response));//
					send_at_command("AT+MCONFIG=c571f83b-e395-4ae2-a8d4-c1589cab57a1,qys,qys\r", response, sizeof(response));
					send_at_command("AT+MIPSTART=118.24.230.64,1883\r", response, sizeof(response));
					send_at_command("AT+MCONNECT=1,120\r", response, sizeof(response));
					sprintf(lcd,"AT+MPUB=pubtopic1,0,0,'%ds%0.2fs%0.2fs%0.2fs%d'\r",temp,pH,conductivity,TDS_value,17-Dt);
					send_at_command(lcd, response, sizeof(response));
					flag_m = 0;
					break;
				
			}
//			if(flag_m = 1)
//			{
//				send_at_command("AT\r", response, sizeof(response));//ȷ�Ͽ���������Ӧ������
//			send_at_command("ATE0\r", response, sizeof(response));//�رջ���
//			send_at_command("AT+ICCID\r", response, sizeof(response));//ȷ��SIM����ã���ѯsim��CCID
//			send_at_command("AT+CGATT?\r", response, sizeof(response));//ȷ���Ƿ񡤸�������
//			send_at_command("AT+CSTT="","",""\r", response, sizeof(response));//����APN
//			send_at_command("AT+CIICR\r", response, sizeof(response));//��������
//		  send_at_command("AT+CIFSR\r", response, sizeof(response));//��ѯIP
//			send_at_command("AT+CPIN?", response, sizeof(response));//
//			send_at_command("AT+MCONFIG=c571f83b-e395-4ae2-a8d4-c1589cab57a1,qys,qys\r", response, sizeof(response));
//			send_at_command("AT+MIPSTART=118.24.230.64,1883\r", response, sizeof(response));
//			send_at_command("AT+MCONNECT=1,120\r", response, sizeof(response));
//			sprintf(lcd,"AT+MPUB=pubtopic1,0,0,'{\\22temp\\22:\\22%d\\22\\22ph\\22:\\22%0.2f\\22\\22muddy\\22:\\22%0.2f\\22\\22conductivity\\22:\\22%0.2f\\22\\22deep\\22:\\22%d\\22}'\r",temp,pH,conductivity,TDS_value,17-Dt);
//			send_at_command(lcd, response, sizeof(response));
//				flag_m = 0;
//			}
			printf("1111");
//			sprintf(lcd,"AT+MSUB=subtopic1,0\r");
//			send_at_command(lcd, response, sizeof(response));
   
		
	




//		HAL_TIM_PWM_Stop(&htim3,TIM_CHANNEL_4);
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV1;
  RCC_OscInitStruct.PLL.PLLN = 10;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

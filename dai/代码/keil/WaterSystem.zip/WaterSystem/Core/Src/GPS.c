#include "main.h"
#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "GPS.h"
#include "usart.h"
#include "WGS84.h"
#include "math.h"
#define printf(...) HAL_UART_Transmit(&huart1,\
										(uint8_t *)u_buf,\
										sprintf((char*)u_buf,__VA_ARGS__),\
										0xffff)

uint8_t u_buf[256];
extern struct GGPS_DATA GPS_DATA;	
//input:AT+CGNSINF Command Response
//output:struct GGPS_DATA	 字符指针origin		 指向struct GGPS_DATA结构体的指针gpsdata。					
void GPS_CGNSINF_Analyze(char *origin,struct GGPS_DATA *gpsdata)
{
	int counter = 0;
    char tmp[150] = {0};
    char *lptr = NULL;
    char *localptr = NULL;
 
    lptr=strstr(origin,"+CGNSINF");//使用strstr函数查找字符串origin中的"+CGNSINF"子串
    if(lptr==NULL)return;
    else lptr+=10;
 
    while(*lptr!='\0')
    {
        if(*lptr==','&&*(lptr+1)==',')
        {//检查逗号分隔的值，并将其存储在临时字符串tmp中
            tmp[counter]=*lptr;
            counter++;
            tmp[counter]='0';
        }
        else if(*lptr=='\r'&&*(lptr+1)=='\n'&&counter<148)
        {
            tmp[counter]   = '0';
            tmp[counter+1] = ',';
            tmp[counter+2] = 0;//遇到换行符时，函数会将换行符替换为逗号，并跳出循环。
            break;
        }
        else
            tmp[counter]=*lptr;
 
        lptr++;
        counter++;
 
        //avoid array out of range 检查数组是否越界
        if(counter>=148)return;
    }
    //Clear struct data memset函数来清除gpsdata结构体的内容
    memset(gpsdata,0,sizeof(struct GGPS_DATA));
 
    localptr = strtok(tmp,",");if(localptr == NULL) return;//使用strtok函数将tmp字符串分割成多个值
    strcpy(gpsdata->GNSSrunstatus,localptr);//这些值分别存储在gpsdata结构体的各个字段中。
 
    localptr = strtok(NULL,",");if(localptr == NULL) return;
    strcpy(gpsdata->Fixstatus,localptr);
 
    localptr = strtok(NULL,",");if(localptr == NULL) return;
    strcpy(gpsdata->UTCdatetime,localptr);
 
    localptr = strtok(NULL,",");if(localptr == NULL) return;
    strcpy(gpsdata->latitude,localptr);
 
    localptr = strtok(NULL,",");if(localptr == NULL) return;
    strcpy(gpsdata->logitude,localptr);
 
    localptr = strtok(NULL,",");if(localptr == NULL) return;
    strcpy(gpsdata->altitude,localptr);
 
    localptr = strtok(NULL,",");if(localptr == NULL) return;
    strcpy(gpsdata->speedOTG,localptr);
 
    localptr = strtok(NULL,",");if(localptr == NULL) return;
    strcpy(gpsdata->course,localptr);
 
    localptr = strtok(NULL,",");if(localptr == NULL) return;
    strcpy(gpsdata->fixmode,localptr);
 
    localptr = strtok(NULL,",");if(localptr == NULL) return;
    strcpy(gpsdata->Reserved1,localptr);
 
    localptr = strtok(NULL,",");if(localptr == NULL) return;
    strcpy(gpsdata->HDOP,localptr);
 
    localptr = strtok(NULL,",");if(localptr == NULL) return;
    strcpy(gpsdata->PDOP,localptr);
 
    localptr = strtok(NULL,",");if(localptr == NULL) return;
    strcpy(gpsdata->VDOP,localptr);
 
    localptr = strtok(NULL,",");if(localptr == NULL) return;
    strcpy(gpsdata->Reserved2,localptr);
 
    localptr = strtok(NULL,",");if(localptr == NULL) return;
    strcpy(gpsdata->satellitesinview,localptr);
 
    localptr = strtok(NULL,",");if(localptr == NULL) return;
    strcpy(gpsdata->GNSSsatellitesused,localptr);
 
    localptr = strtok(NULL,",");if(localptr == NULL) return;
    strcpy(gpsdata->GLONASSsatellitesused,localptr);
 
    localptr = strtok(NULL,",");if(localptr == NULL) return;
    strcpy(gpsdata->Reserved3,localptr);
 
    localptr = strtok(NULL,",");if(localptr == NULL) return;
    strcpy(gpsdata->CN0max,localptr);
 
    localptr = strtok(NULL,",");if(localptr == NULL) return;
    strcpy(gpsdata->HPA,localptr);
 
    localptr = strtok(NULL,"\r\n");if(localptr == NULL) return;
    strcpy(gpsdata->VPA,localptr);
}





 char RECS[250];
const char* ClintID="c571f83b-e395-4ae2-a8d4-c1589cab57a1\,signmethod=hmacsha256\,timestamp=1701340327871|";
const char* username="qys";
const char* passwd="qys";
const char* Url0="ntp1.aliyun.com";
const char* Url="i118.24.230.64";

const char* pubtopic="pubtopic1";
const char* subtopic1="/pubtopic1/Device_ESP/user/get";
const char* subtopic2="/k0bcjY07SxE/Device_ESP/user/get";

const char* func1="location";
const char* func2="Humidity";
const char* func3="PowerSwitch_1";
const char* func4="PowerSwitch_2";

									
 
char G_Publish_Aliyun(void)//??
{
	memset(RECS,0,sizeof(RECS));//½«RECSÊý×éÈ«²¿ÉèÖÃÎª0
	//printf("AT+MQTTPUB=0,\"%s\",\"{\\\"method\\\":\\\"thing.event.property.post\\\"\\,\\\"params\\\":{\\\"%s\\\":%d\\,\\\"%s\\\":%d\\,\\\"%s\\\":%d\\,\\\"%s\\\":%d}}\",0,0\r\n",pubtopic,func1,Temperature,func2,Humidity,func3,PowerSwitch_1,func4,PowerSwitch_2);
	HAL_Delay(200);//ÑÓÊ±µÈ´ýÊý¾Ý½ÓÊÕÍê³É
	if(strcmp(RECS,"ERROR")==0)
	{
		return 1;//·¢ËÍÊ§°Ü
	}
	return 0;//·¢ËÍ³É¹¦
}

/**
  * @brief          ´®¿Ú1Êý¾Ý½ÓÊÕ´¦Àíº¯Êý
  * @param[in]      none
  * @retval         none
  */
unsigned char receive_data[400] = {0};  
void uart2_receiver_handle(void)
{
	HAL_UART_Receive(&huart3,receive_data,400,50);
 	printf("%s\n",receive_data);
	memset(receive_data,0x00,1000);
}
 
void Alyun(void)
{
  printf("AT\r");    //ÉèÖÃ×Ô¶¯Ñ¡ÔñAPN		
	uart2_receiver_handle();
	HAL_Delay(2000);
	
    printf("AT\r");    //ÉèÖÃ×Ô¶¯Ñ¡ÔñAPN	
uart2_receiver_handle();	
	HAL_Delay(2000);
  	
	  printf("AT+CGMI\r");
uart2_receiver_handle();	
	HAL_Delay(2000);
	
	  printf("AT+CPIN?\r");
uart2_receiver_handle();	
	HAL_Delay(2000);
	
	  printf("AT+CSQ\r"); 
	uart2_receiver_handle();
	HAL_Delay(2000);
	
	  printf("AT+CREG?\r");
uart2_receiver_handle();	  
	HAL_Delay(2000);
	
	 printf("AT+CGATT?\r");
uart2_receiver_handle();	 
	HAL_Delay(2000);
	
  printf("AT+CSTT=\"\",\"\",\"\" \r");
uart2_receiver_handle();  
	HAL_Delay(2000);	

	printf("AT+CIICR\r\n"); 	//¼¤»îÒÆ¶¯³¡¾°
	uart2_receiver_handle();
  	HAL_Delay(2000);
	
	printf("AT+CIFSR\r\n");//²éÑ¯ip
	uart2_receiver_handle();
	HAL_Delay(2000);
	
	printf("AT+MCONFIG=\"%s\",\"%s\",\"%s\"\r\n",ClintID,username,passwd); //Á¬½Ó·þÎñÆ÷ÅäÖÃ
	uart2_receiver_handle();
	HAL_Delay(2000);
	
	printf("AT+MIPSTART=\"%s\",1883\r",Url); //ÉèÖÃmqtt°¢ÀïÔÆ²ÎÊý
	uart2_receiver_handle();
	HAL_Delay(2000);

	printf("AT+MCONNECT=1,120\r");//ÉèÖÃÐÄÌøÊ±¼ä
	uart2_receiver_handle();
	HAL_Delay(2000);
}
const char* UrlT="bj-2-mqtt.iot-api.com";
void ThingsCloud(void)
{
	 printf("AT");    //ÉèÖÃ×Ô¶¯Ñ¡ÔñAPN		

	HAL_Delay(1000);
	HAL_Delay(1000);
    printf("AT");    	

	HAL_Delay(1000);
	HAL_Delay(1000);
   printf("AT+CSTT="","","" \r");    	

	HAL_Delay(1000);
	HAL_Delay(1000);
   printf("AT+CIICR\r");    	

	HAL_Delay(1000);
	HAL_Delay(1000);
   printf("AT+CIFSR\r");    	
	uart2_receiver_handle();

  HAL_Delay(1000);
	HAL_Delay(1000);
   printf("AT+MCONFIG=thingscloud,4hpfrlk4hilor4f3,BgLFgXul3Y\r");   
   HAL_Delay(1000);
	HAL_Delay(1000);
   printf("AT+MIPSTART=\"%s\",1883\r",UrlT);   
   HAL_Delay(1000);
	HAL_Delay(1000);
   printf("AT+MCONNECT=0,300\r");   
   HAL_Delay(1000);
	HAL_Delay(1000);

}

void G4_Publish(void)
{
	//alyun
	HAL_Delay(2000);
	printf("AT+MSUB=\"%s\",1\r\n",pubtopic);
	uart2_receiver_handle();	
	//printf("%s",GPS_DATA.UTCdatetime);
	
	HAL_Delay(2000);
	printf("AT+MPUB=\"%s\",1,0,\"{\\22params\\22:{\\22GnssTime\\22:%s}}\"\r",pubtopic,GPS_DATA.UTCdatetime);//时间
	uart2_receiver_handle();	
	
	HAL_Delay(2000);
	printf("AT+MPUB=\"%s\",1,0,\"{\\22params\\22:{\\22Latitude\\22:%s}}\"\r",pubtopic,GPS_DATA.altitude);//纬度
	uart2_receiver_handle();	
	
	HAL_Delay(2000);
	printf("AT+MPUB=\"%s\",1,0,\"{\\22params\\22:{\\22precision\\22:%s}}\"\r",pubtopic,GPS_DATA.logitude);//经度
	uart2_receiver_handle();	
	
	
	//thingcloud  location
//	printf("AT+MPUB=attributes,0,0,{\\22location\\22:{\\22lat\\22:41.0203\2C\\22lng\\22:38.3183}}\r");   
//	uart2_receiver_handle();	
//	HAL_Delay(2000);


	
}
char str[100]={""};//GPS数据
void G4_Open(void)
{
	printf("AT+CSQ\r"); 
	uart2_receiver_handle();
	HAL_Delay(2000);
	
	printf("AT+CGNSPWR=1\r"); 
	uart2_receiver_handle();
	HAL_Delay(2000);
	printf("AT+CGNSAID=1,1,1,1\r"); 
	uart2_receiver_handle();
	HAL_Delay(2000);

	printf("AT+CGNSINF\r"); 
	HAL_UART_Receive(&huart1,str,100,50);
 	printf("%s\r\n",str);

//	printf("AT+CGNSURC=1\r"); //设置定位信息自动上报，每隔5个fix，就上报一次	
//	HAL_Delay(2000);
}
void G4_inquire(void)
{
	printf("AT+CGNSINF\r"); 
	HAL_UART_Receive(&huart1,str,100,50);
 	printf("%s\r\n",str);
}
double xlat,xlon;
double	newlat,newlon;
MyStruct wgs84;
void NowWGS84(void)
{
	double	lon=0;
	double	lonn=0;
	uint8_t i=0;
	strcpy(GPS_DATA.logitude, "106.514984");
 for (int i = 0; i < 12; i++) {
      if(GPS_DATA.logitude[i]!=0x2E)
wgs84.logitude[i]=GPS_DATA.logitude[i]-'0';
	 else
	 {wgs84.logitude[i]=(GPS_DATA.logitude[i]);
//		  printf("%c",GPS_DATA.logitude[i]);
//		 printf("%d",wgs84.logitude[i]);
	 }
 }

while(wgs84.logitude[i]!=46){//整数
	 lon=lon*10+wgs84.logitude[i];
	i++;
	 }
	 i=i+1;
	 int m=1;
while(i!=11){//小数
	m=m*10;
	lonn=lonn+wgs84.logitude[i]/m;
	i++;
}
xlon=lon+lonn;
printf("%lf\n",xlon);
 //纬度
	double	lat=0;
	double	latt=0;
uint8_t j=0;
 strcpy(GPS_DATA.latitude, "29.363035");
for (int j = 0; j < 9; j++) {
      if(GPS_DATA.latitude[j]!=0x2E)
wgs84.latitude[j]=GPS_DATA.latitude[j]-'0';
	 else
	 {wgs84.latitude[j]=(GPS_DATA.latitude[j]);
		 // printf("%c",GPS_DATA.latitude[j]);
	 }
 }
while(wgs84.latitude[j]!=46){//整数
	 lat=lat*10+wgs84.latitude[j];
	j++;
	 }
	 j=j+1;
	int n=1;
while(j!=9){//小数
	n=n*10;
	latt=latt+wgs84.latitude[j]/n;
	j++;
}
	xlat=lat+latt;
printf("%lf\n",xlat);

	WGS84toGCJ02(xlat, xlon, &newlat, &newlon);
   printf("WGS84toGCJ02:%lf-%lf >>> %lf-%lf\n", xlat, xlon, newlat, newlon);

//	printf("-------------------------------------------\r\n"); 
	HAL_Delay(2000);
}
void ll(void){



}

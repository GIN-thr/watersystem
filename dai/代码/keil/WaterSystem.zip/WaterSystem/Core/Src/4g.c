#include  "4g.h"
#include  "main.h"
#include  "usart.h"
#include  "stdlib.h"
#include  "stdio.h"
#include  "string.h"

#define printf(...) HAL_UART_Transmit(&huart1,\
										(uint8_t *)u_buf,\
										sprintf((char*)u_buf,__VA_ARGS__),\
										0xffff)

uint8_t u_buf[256];

 char RECS[250];
const char* ClintID="k0bcjaVX8ci.air820|securemode=2\\,signmethod=hmacsha256\\,timestamp=1701142192640|";
const char* username="air820&k0bcjaVX8ci";
const char* passwd="02fdb662308b986838385be17a4006caa9ce23e2246bc28f5eada7efd4b45a5e";
const char* Url0="ntp1.aliyun.com";
const char* Url="iot-06z00cf3bszw841.mqtt.iothub.aliyuncs.com";

const char* pubtopic="/sys/k0bcjaVX8ci/air820/thing/event/property/post";
const char* subtopic1="/k0bcjY07SxE/Device_ESP/user/get";
const char* subtopic2="/k0bcjY07SxE/Device_ESP/user/get";

const char* func1="temperature";
const char* func2="Humidity";
const char* func3="PowerSwitch_1";
const char* func4="PowerSwitch_2";

 
char G_Publish_Aliyun(void)//??
{
	memset(RECS,0,sizeof(RECS));//��RECS����ȫ������Ϊ0
	//printf("AT+MQTTPUB=0,\"%s\",\"{\\\"method\\\":\\\"thing.event.property.post\\\"\\,\\\"params\\\":{\\\"%s\\\":%d\\,\\\"%s\\\":%d\\,\\\"%s\\\":%d\\,\\\"%s\\\":%d}}\",0,0\r\n",pubtopic,func1,Temperature,func2,Humidity,func3,PowerSwitch_1,func4,PowerSwitch_2);
	HAL_Delay(200);//��ʱ�ȴ����ݽ������
	if(strcmp(RECS,"ERROR")==0)
	{
		return 1;//����ʧ��
	}
	return 0;//���ͳɹ�
}

/**
  * @brief          ����1���ݽ��մ�������
  * @param[in]      none
  * @retval         none
  */
unsigned char receive_data[300] = {0};   
void uart2_receiver_handle(void)
{
    
	if(receive_data!=NULL)
	HAL_UART_Receive(&huart1,receive_data,200,50);
 	printf("%s\n",receive_data);
//	memset(receive_data,0x00,1000);
}
void G4_Publish(void)
{
	// printf("AT+MPUB=\"%s\",1,0,\\"{\\"params\\":{\\"temperature\\":7}}\\"\r",pubtopic);
	uart2_receiver_handle();	
	HAL_Delay(2000);
	printf("AT+MSUB=\"%s\",1\r\n",pubtopic);
	uart2_receiver_handle();	
	HAL_Delay(2000);
}
void G4_Open(void)
{
//	printf("AT+CSQ\r"); 
//	uart2_receiver_handle();
//	HAL_Delay(2000);
//	
//	printf("AT+CGNSPWR=1\r"); 
//	uart2_receiver_handle();
//	HAL_Delay(2000);
//	printf("AT+CGNSAID=1,1,1,1\r"); 
//	uart2_receiver_handle();
//	HAL_Delay(2000);
	printf("AT+CGNSINF\r"); 
	uart2_receiver_handle();
	HAL_Delay(2000);
//	
//	printf("AT+CGNSURC=1\r"); 
//	uart2_receiver_handle();
//	HAL_Delay(2000);

}
 
void Alyun(void)
{
  printf("AT\r");    //�����Զ�ѡ��APN		
	uart2_receiver_handle();
	HAL_Delay(2000);
	
    printf("AT\r");    //�����Զ�ѡ��APN	
uart2_receiver_handle();	
	HAL_Delay(2000);
  	
	  printf("AT+CGMI\r");
uart2_receiver_handle();	
	HAL_Delay(2000);
	
	  printf("AT+CPIN?\r");
uart2_receiver_handle();	
	HAL_Delay(2000);
	
	  printf("AT+CSQ\r"); 
	uart2_receiver_handle();
	HAL_Delay(2000);
	
	  printf("AT+CREG?\r");
uart2_receiver_handle();	  
	HAL_Delay(2000);
	
	 printf("AT+CGATT?\r");
uart2_receiver_handle();	 
	HAL_Delay(2000);
	
  printf("AT+CSTT=\"\",\"\",\"\" \r");
uart2_receiver_handle();  
	HAL_Delay(2000);	

	printf("AT+CIICR\r\n"); 	//�����ƶ�����
	uart2_receiver_handle();
  	HAL_Delay(2000);
	
	printf("AT+CIFSR\r\n");//��ѯip
	uart2_receiver_handle();
	HAL_Delay(2000);
	
	printf("AT+MCONFIG=\"%s\",\"%s\",\"%s\"\r",ClintID,username,passwd); //���ӷ���������
	uart2_receiver_handle();
	HAL_Delay(2000);
	
	printf("AT+MIPSTART=\"%s\",1883\r",Url); //����mqtt�����Ʋ���
	uart2_receiver_handle();
	HAL_Delay(2000);

	printf("AT+MCONNECT=1,120\r");//��������ʱ��
	uart2_receiver_handle();
	HAL_Delay(2000);
}
const char* UrlT="bj-2-mqtt.iot-api.com";
void ThingsCloud(void)
{
	 printf("AT");    //�����Զ�ѡ��APN		

	HAL_Delay(1000);
	HAL_Delay(1000);
    printf("AT");    	

	HAL_Delay(1000);
	HAL_Delay(1000);
   printf("AT+CSTT="","","" \r");    	

	HAL_Delay(1000);
	HAL_Delay(1000);
   printf("AT+CIICR\r");    	

	HAL_Delay(1000);
	HAL_Delay(1000);
   printf("AT+CIFSR\r");    	

  HAL_Delay(1000);
	HAL_Delay(1000);
   printf("AT+MCONFIG=thingscloud,4hpfrlk4hilor4f3,BgLFgXul3Y\r");   
   HAL_Delay(1000);
	HAL_Delay(1000);
   printf("AT+MIPSTART=\"%s\",1883\r",UrlT);   
   HAL_Delay(1000);
	HAL_Delay(1000);
   printf("AT+MCONNECT=0,300\r");   
   HAL_Delay(1000);
	HAL_Delay(1000);
   printf("AT+MPUB=attributes,0,0,{\\22temperature\\22:39}\r");   
	HAL_Delay(1000);
	HAL_Delay(1000);
}


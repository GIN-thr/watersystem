const app = getApp()
var mqtt = require('../../utils/mqtt.min.js')

Page({
  data: {
    message: '',
  },
  onLoad:function(options) {
    var that = this
    that.connectMqtt()
    // this.connectMqtt()
  },
  connectMqtt:function(){
    var that = this;
    const options = {
      connectTimeout:4000,
      clientId:'71b8746c176635445ef4c5466ba97cf9',
      port:8084,
      username:'71b8746c176635445ef4c5466ba97cf9',
      password:'root'
    }
    client = mqtt.connect('wxs://t.yoyolife.fun:8084/mqtt',options)
    client.on('connect',(e)=>
    {
      console.log('服务器连接成功')
      client.subscribe('/iot/5751/xx',
      {
        qos:0, 
      },
      
      function(err)
      {
        if(!err)
        {
            console.log('订阅成功')
        }
      })
    })
    client.on('message',function(topic,message){
      console.log('收到'+message.toString())
      that.setData({
        message: message.toString(),
      })
    })
  },
})

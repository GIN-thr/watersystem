// pages/myInfo/myInfo.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    myInfo: [],
    serch: '',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    // setInterval(this.updateInfo, 3000);
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    this.setData({
      myInfo: getApp().globalData.info,
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },
  updateInfo(){
    this.setData({
      myInfo: getApp().globalData.info,
    })
  },
  findEventsByTitle() {
    var title = this.data.serch;
    const app = getApp()
    const regex = new RegExp(title, 'i') // 'i'表示不区分大小写
    this.setData({
      myInfo:app.globalData.info.filter(event => regex.test(event.title))
    })
  },
  onSerchInput(e) {
    this.setData({
      serch: e.detail.value,
    });
  },
  Fanhui(){
    wx.switchTab({
      url: '/pages/me/me'
    })
  }
})
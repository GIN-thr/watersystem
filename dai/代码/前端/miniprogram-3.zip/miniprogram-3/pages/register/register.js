// pages/register/register.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    username: '',
    password: '',
    ppassword: '',
    touxiang: '',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },
  onUsernameInput(e) {
    var that = this;
    that.setData({
      username: e.detail.value,
    });
  },

  onPasswordInput(e) {
    var that = this;
    that.setData({
      password: e.detail.value,
    });
  },

  onPPasswordInput(e) {
    var that = this;
    that.setData({
      ppassword: e.detail.value,
    });
  },
  register() {
    var that = this;
    if (that.data.ppassword != that.data.password) {
      wx.showToast({
        title: '密码不一致',
        icon: 'error',
        duration: 1500
      });
      return false;
    }
    wx.request({
      url: 'http://localhost:8083/register',
      method: 'GET',
      data: {
        username: that.data.username,
        password: that.data.password,
        touxiang: '../img/touxiang.jpg',
      },
      header: {
        'content-type': 'json'
      },
      success(res) {
        if (res.data == 'ok') {
          wx.navigateTo({
            url: '/pages/login/login'
          });
        }else{
          wx.showToast({
            title: '账号已注册',
            icon: 'error',
            duration: 1500
          });
          return false;
        }
      }
    });
  },
})
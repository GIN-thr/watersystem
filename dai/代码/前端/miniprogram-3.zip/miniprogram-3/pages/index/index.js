// index.js

const app = getApp()
var mqtt = require('../../utils/mqtt.min.js')
var client = null;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    temperature: 1.0,
    PH: 1.0,
    muddy: 1.0,
    conductivity: 1.0,
    deep: 1.0,
    dev1_s: '良好',
    dev2_s: '良好',
    dev3_s: '良好',
    dev4_s: '良好',
    dev5_s: '良好',
    dev1_c: '#79B479',
    dev2_c: '#79B479',
    dev3_c: '#79B479',
    dev4_c: '#79B479',
    dev5_c: '#79B479',
    weather_inform: {},
    state: '已断开',
    state_color: '#FF0000',
    op: '连接',
    op_color: '#FF0000',
    weather_src: '',
    pingu: '',
    pingu_color: '',
    conInfo_state: 'none',
    clientId: '',
    port: 8084,
    username: '',
    subscribe: 'pub',
    password: '',
    host: 'wxs://broker.emqx.io:8084/mqtt',

    // host: 'wxs://broker-cn.emqx.io:8084/mqtt',
    // host: '118.24.230.64',
    menban: 'none',
    temp_min: 0,
    temp_max: 0,
    ph_min: 0,
    ph_max: 0,
    deep_min: 0,
    deep_max: 0,
    muddy_min: 0,
    muddy_max: 0,
    conductivity_min: 0,
    conductivity_max: 0,
    i: 0,
    tjInfo: [],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    var that = this;
    that.getWeather();
    that.setData({
      temp_min: getApp().globalData.temp_min,
      temp_max: getApp().globalData.temp_max,
      ph_min: getApp().globalData.ph_min,
      ph_max: getApp().globalData.ph_max,
      deep_min: getApp().globalData.deep_min,
      deep_max: getApp().globalData.deep_max,
      muddy_min: getApp().globalData.muddy_min,
      muddy_max: getApp().globalData.muddy_max,
      conductivity_min: getApp().globalData.conductivity_min,
      conductivity_max: getApp().globalData.conductivity_max,
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    if (this.data.dev1_s != '良好') {
      this.setData({
        dev1_c: '#B95548',
      });
    }
    if (this.data.dev2_s != '良好') {
      this.setData({
        dev2_c: '#B95548',
      });
    }
    if (this.data.dev3_s != '良好') {
      this.setData({
        dev3_c: '#B95548',
      });
    }
    if (this.data.dev4_s != '良好') {
      this.setData({
        dev4_c: '#B95548',
      });
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },
  connectMqtt: function () {
    var that = this;
    const options = {
      connectTimeout: 4000,
      clientId: that.data.clientId,
      port: that.data.port,
      username: that.data.username,
      password: that.data.password
    }
    //client = mqtt.connect('wxs://t.yoyolife.fun:8084/mqtt', options)
    client = mqtt.connect(that.data.host, options)

    client.on('connect', (e) => {
      console.log('服务器连接成功')
      client.subscribe(that.data.subscribe, {
          qos: 0,
        },

        function (err) {
          if (!err) {
            console.log('订阅成功')
            that.setData({
              op: '断开',
              op_color: '#5EFF66',
              state: '已连接',
              state_color: '#5EFF66',
            })
          }
        })
    })
    client.on('message', function (topic, message) {
      var message = JSON.parse(message);
      console.log(message)
      that.setData({
        tjInfo: that.data.tjInfo.concat(message),
      })
      that.data.i = that.data.i + 1;
      if (that.data.i >= 6) {
        getApp().globalData.tjInfo = that.data.tjInfo;
        that.data.i = 0;
        that.data.tjInfo = [];
        console.log(getApp().globalData.tjInfo);
      }
      that.setData({
        temperature: message.temp,
        PH: message.ph,
        muddy: message.muddy,
        conductivity: message.conductivity,
        deep: message.deep,
      })
      that.pingu();
    })
    client.on('offline', () => {
      console.log('服务器连接断开，尝试重新连接')
      that.setData({
        op: '连接',
        op_color: '#FF0000',
        state: '已断开',
        state_color: '#FF0000',
      })
      client.reconnect()
    })
  },

  pingu() {
    var that = this;
    that.setData({
      pingu_color: 'red',
      pingu: '',
    })
    if (that.data.temperature < that.data.temp_min) {
      that.setData({
        pingu: that.data.pingu + '温度低 ',
      })
    } else if (that.data.temperature > that.data.temp_max) {
      that.setData({
        pingu: that.data.pingu + '温度高 ',
      })
    }
    if (that.data.PH < that.data.ph_min) {
      that.setData({
        pingu: that.data.pingu + 'PH值低 ',
      })
    } else if (that.data.PH > that.data.ph_max) {
      that.setData({
        pingu: that.data.pingu + 'PH值高 ',
      })
    }
    if (that.data.muddy > that.data.muddy_max) {
      that.setData({
        pingu: that.data.pingu + '水体浑浊 ',
      })
    }
    if (that.data.deep < that.data.deep_min) {
      that.setData({
        pingu: that.data.pingu + '水面较低 ',
      })
    }
    if (that.data.conductivity < that.data.conductivity_min) {
      that.setData({
        pingu: that.data.pingu + '导电率低',
      })
    }
    if (that.data.conductivity > that.data.conductivity_max) {
      that.setData({
        pingu: that.data.pingu + '导电率高',
      })
    }
    if (that.data.pingu == '') {
      that.setData({
        pingu: '良好',
        pingu_color: 'green',
      })
    }
    const now = new Date();
    const year = now.getFullYear();
    const month = now.getMonth() + 1;
    const date = now.getDate();
    const hours = now.getHours();
    const minutes = now.getMinutes();
    var time = year + "/" + month + "/" + date + "/" + hours + "/" + minutes;
    var info = {
      title: that.data.pingu,
      time: time
    };
    if (that.data.pingu != "良好") {
      if (getApp().globalData.info.length == 0 || that.data.pingu != getApp().globalData.info[getApp().globalData.info.length - 1].title) {
        getApp().globalData.info = getApp().globalData.info.concat(info);
        console.log(getApp().globalData.info);
      }
    }
  },

  getWeather() {
    var that = this;
    wx.request({
      url: 'https://restapi.amap.com/v3/weather/weatherInfo',
      data: {
        'key': '06ecbf78b98f67b8927348dc0327a35e',
        'city': '500113',
      },
      success: function (res) {
        that.setData({
          weather_inform: res.data,
        })
        that.setWeather();
        console.log(that.data.weather_inform);
      }
    })
  },
  setWeather() {
    var that = this;
    if (that.data.weather_inform.lives[0].weather == '晴') {
      that.setData({
        weather_src: 'http://localhost:8081/img/晴天.png',
      })
    } else if (that.data.weather_inform.lives[0].weather == '阴') {
      that.setData({
        weather_src: 'http://localhost:8081/img/阴天.png',
      })
    } else if (that.data.weather_inform.lives[0].weather == '多云') {
      that.setData({
        weather_src: 'http://localhost:8081/img/多云.png',
      })
    } else if (that.data.weather_inform.lives[0].weather == '小雨' || that.data.weather_inform.lives[0].weather == '雨') {
      that.setData({
        weather_src: 'http://localhost:8081/img/小雨.png',
      })
    } else if (that.data.weather_inform.lives[0].weather == '中雨') {
      that.setData({
        weather_src: 'http://localhost:8081/img/中雨.png',
      })
    } else if (that.data.weather_inform.lives[0].weather == '大雨') {
      that.setData({
        weather_src: 'http://localhost:8081/img/大雨.png',
      })
    } else if (that.data.weather_inform.lives[0].weather == '暴雨') {
      that.setData({
        weather_src: 'http://localhost:8081/img/暴雨.png',
      })
    } else if (that.data.weather_inform.lives[0].weather == '阵雨') {
      that.setData({
        weather_src: 'http://localhost:8081/img/阵雨.png',
      })
    } else if (that.data.weather_inform.lives[0].weather == '雷阵雨') {
      that.setData({
        weather_src: 'http://localhost:8081/img/雷阵雨.png',
      })
    } else if (that.data.weather_inform.lives[0].weather == '小雪') {
      that.setData({
        weather_src: 'http://localhost:8081/img/小雪.png',
      })
    } else if (that.data.weather_inform.lives[0].weather == '中雪') {
      that.setData({
        weather_src: 'http://localhost:8081/img/中雪.png',
      })
    } else if (that.data.weather_inform.lives[0].weather == '大雪') {
      that.setData({
        weather_src: 'http://localhost:8081/img/大雪.png',
      })
    } else if (that.data.weather_inform.lives[0].weather == '暴雪') {
      that.setData({
        weather_src: 'http://localhost:8081/img/暴雪.png',
      })
    } else if (that.data.weather_inform.lives[0].weather == '阵雪') {
      that.setData({
        weather_src: 'http://localhost:8081/img/阵雪.png',
      })
    } else if (that.data.weather_inform.lives[0].weather == '雾') {
      that.setData({
        weather_src: 'http://localhost:8081/img/雾.png',
      })
    }
  },

  con() {
    var that = this;
    if (that.data.op == '连接') {
      that.setData({
        op: '等待',
        op_color: '#FFCA28',
        state: '连接中',
        state_color: '#FFCA28',
        conInfo_state: 'none',
      })
      that.connectMqtt();
    } else {
      client.end();
      that.setData({
        op: '连接',
        op_color: '#FF0000',
        state: '已断开',
        state_color: '#FF0000',
      })
    }
  },

  showCon() {
    var that = this;
    if (client != null) {
      client.end();
      that.setData({
        op: '连接',
        op_color: '#FF0000',
        state: '已断开',
        state_color: '#FF0000',
      })
    }
    if (that.data.conInfo_state == 'none') {
      that.setData({
        conInfo_state: 'block'
      })
    } else {
      that.setData({
        conInfo_state: 'none'
      })
    }

  },
  clientId(e) {
    var that = this;
    that.setData({
      clientId: e.detail.value,
    })
  },
  port(e) {
    var that = this;
    that.setData({
      port: e.detail.value,
    })
  },
  cusername(e) {
    var that = this;
    that.setData({
      cusername: e.detail.value,
    })
  },
  password(e) {
    var that = this;
    that.setData({
      password: e.detail.value,
    })
  },
  host(e) {
    var that = this;
    that.setData({
      host: e.detail.value,
    })
  },
  subscribe(e) {
    var that = this;
    that.setData({
      subscribe: e.detail.value,
    })
  },
  setting() {
    var that = this;
    that.setData({
      menban: "block",
    })
    console.log(that.data.menban);
  },
  quxiao() {
    var that = this;
    that.setData({
      menban: 'none',
      temp_min: getApp().globalData.temp_min,
      temp_max: getApp().globalData.temp_max,
      ph_min: getApp().globalData.ph_min,
      ph_max: getApp().globalData.ph_max,
      deep_min: getApp().globalData.deep_min,
      deep_max: getApp().globalData.deep_max,
      muddy_min: getApp().globalData.muddy_min,
      muddy_max: getApp().globalData.muddy_max,
      conductivity_min: getApp().globalData.conductivity_min,
      conductivity_max: getApp().globalData.conductivity_max,
    })
  },
  save() {
    getApp().globalData.temp_min = this.data.temp_min;
    getApp().globalData.temp_max = this.data.temp_max;
    getApp().globalData.ph_min = this.data.ph_min;
    getApp().globalData.ph_max = this.data.ph_max;
    getApp().globalData.deep_min = this.data.deep_min;
    getApp().globalData.deep_max = this.data.deep_max;
    getApp().globalData.muddy_min = this.data.muddy_min;
    getApp().globalData.muddy_max = this.data.muddy_max;
    getApp().globalData.conductivity_min = this.data.conductivity_min;
    getApp().globalData.conductivity_max = this.data.conductivity_max;
    this.quxiao();
  },
  ontemp_min(e) {
    this.data.temp_min = e.detail.value;
  },
  ontemp_max(e) {
    this.data.temp_max = e.detail.value;
  },
  ondeep_min(e) {
    this.data.deep_min = e.detail.value;
  },
  ondeep_max(e) {
    this.data.deep_max = e.detail.value;
  },
  onph_min(e) {
    this.data.ph_min = e.detail.value;
  },
  onph_max(e) {
    this.data.ph_max = e.detail.value;
  },
  onmuddy_min(e) {
    this.data.muddy_min = e.detail.value;
  },
  onmuddy_max(e) {
    this.data.muddy_max = e.detail.value;
  },
  onconductivity_min(e) {
    this.data.conductivity_min = e.detail.value;
  },
  onconductivity_max(e) {
    this.data.conductivity_max = e.detail.value;
  },
  tj() {
    wx.switchTab({
      url: '/pages/statistics/statistics'
    })
  }
})
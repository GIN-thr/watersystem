// pages/statistics/statistics.js
import wxCharts from '../API/wxcharts.js'
Page({

  /**
   * 页面的初始数据
   */
  data: {
    
  },

  /**
   * 生命周期函数--监听页面加载
   */

  onLoad(options) {
    setInterval(this.updateCharts, 6000);
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },
  updateCharts() {
    new wxCharts({
      canvasId: 'temp',
      type: 'line',
      categories: ['', '', '', '', '', ''],
      series: [{
        name: '温度',
        data: [getApp().globalData.tjInfo[0].temp, getApp().globalData.tjInfo[1].temp, getApp().globalData.tjInfo[2].temp, getApp().globalData.tjInfo[3].temp, getApp().globalData.tjInfo[4].temp, getApp().globalData.tjInfo[5].temp],
        format: function (val) {
          return val.toFixed(2);
        }
      }],
      yAxis: {
        title: '温度 (℃)',
        format: function (val) {
          return val.toFixed(2);
        },
        min: 0
      },
      width: 350,
      height: 200,
      background: '#F3F3F3',
      color: 'red'
    });
    new wxCharts({
      canvasId: 'PH',
      type: 'line',
      categories: ['', '', '', '', '', ''],
      series: [{
        name: 'PH',
        data: [getApp().globalData.tjInfo[0].ph, getApp().globalData.tjInfo[1].ph, getApp().globalData.tjInfo[2].ph, getApp().globalData.tjInfo[3].ph, getApp().globalData.tjInfo[4].ph, getApp().globalData.tjInfo[5].ph],
        format: function (val) {
          return val.toFixed(2);
        }
      }],
      yAxis: {
        title: 'PH (mol/l)',
        format: function (val) {
          return val.toFixed(2);
        },
        min: 0
      },
      width: 350,
      height: 200,
      background: '#F3F3F3',
    });
    new wxCharts({
      canvasId: 'muddy',
      type: 'line',
      categories: ['', '', '', '', '', ''],
      series: [{
        name: '浑浊度',
        data: [getApp().globalData.tjInfo[0].muddy, getApp().globalData.tjInfo[1].muddy, getApp().globalData.tjInfo[2].muddy, getApp().globalData.tjInfo[3].muddy, getApp().globalData.tjInfo[4].muddy, getApp().globalData.tjInfo[5].muddy],
        format: function (val) {
          return val.toFixed(2);
        }
      }],
      yAxis: {
        title: '浑浊度 (cm)',
        format: function (val) {
          return val.toFixed(2);
        },
        min: 0
      },
      width: 350,
      height: 200,
      background: '#F3F3F3',
    });
    new wxCharts({
      canvasId: 'conductivity',
      type: 'line',
      categories: ['', '', '', '', '', ''],
      series: [{
        name: '导电率',
        data: [getApp().globalData.tjInfo[0].conductivity, getApp().globalData.tjInfo[1].conductivity, getApp().globalData.tjInfo[2].conductivity, getApp().globalData.tjInfo[3].conductivity, getApp().globalData.tjInfo[4].conductivity, getApp().globalData.tjInfo[5].conductivity],
        format: function (val) {
          return val.toFixed(2);
        }
      }],
      yAxis: {
        title: '导电率 (G)',
        format: function (val) {
          return val.toFixed(2);
        },
        min: 0
      },
      width: 350,
      height: 200,
      background: '#F3F3F3',
    });
    new wxCharts({
      canvasId: 'deep',
      type: 'line',
      categories: ['', '', '', '', '', ''],
      series: [{
        name: '深度',
        data: [getApp().globalData.tjInfo[0].deep, getApp().globalData.tjInfo[1].deep, getApp().globalData.tjInfo[2].deep, getApp().globalData.tjInfo[3].deep, getApp().globalData.tjInfo[4].deep, getApp().globalData.tjInfo[5].deep],
        format: function (val) {
          return val.toFixed(2);
        }
      }],
      yAxis: {
        title: '深度 (M)',
        format: function (val) {
          return val.toFixed(2);
        },
        min: 0
      },
      width: 350,
      height: 200,
      background: '#F3F3F3',
    });
  },
})
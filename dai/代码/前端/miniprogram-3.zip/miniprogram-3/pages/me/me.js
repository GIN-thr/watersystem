// pages/me/me.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    touxiang: 'http://localhost:8083/img/logo.png',
    username: '请登录',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.setData({
      username: getApp().globalData.username,
      touxiang: getApp().globalData.touxiang
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },
  saveImg() {
    var that = this;
    wx.request({
      url: 'http://localhost:8083/saveMyInfo',
      method: 'GET',
      data: {
        username: that.data.username,
        touxiang: that.data.touxiang,
      },
      header: {
        'content-type': 'json'
      },
      success(res) {
        if (res.data == 'ok') {
          getApp().globalData.touxiang = that.data.touxiang;
          wx.showToast({
            title: '已保存',
            icon: 'success',
            duration: 1500
          });
        }
      }
    });
  },
  bindchooseavatar(e) {
    var that = this;
    that.setData({
      touxiang: e.detail.avatarUrl,
    });
    that.saveImg();
  },
})
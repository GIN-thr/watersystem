package com.waterexaminatonsystem.Sercivelmpl;

import com.waterexaminatonsystem.JavaBean.User;
import com.waterexaminatonsystem.Mapper.UserMapper;
import com.waterexaminatonsystem.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class UserServicelmpl implements UserService {
    @Autowired
    private UserMapper userMapper;
    //    用户端
    @Override
    public int login(User user) {
        int result = userMapper.login(user);
        return result;
    }

    @Override
    public int register(User user) {
        int result = userMapper.register(user);
        return result;
    }

    @Override
    public int selectPhone(User user) {
        int result = userMapper.selectPhone(user);
        return result;
    }

    //管理端
    @Override
    public List<User> selectAllUser(User user) {
        List<User> list = userMapper.selectAllUser(user);
        return list;
    }

    @Override
    public void deleteUser(User user) {
        userMapper.deleteUser(user);

    }

    @Override
    public void updateUser(User user) {

        userMapper.updateUser(user);
    }

    @Override
    public List<User> selectUserName(User user) {
        List<User> list = userMapper.selectUserName(user);
        return list;
    }

    @Override
    public void userUpdatePassword(User user) {
        userMapper.userUpdatePassword(user);
    }

    @Override
    public int selectUserCount() {
        int num = userMapper.selectUserCount();
        return num;
    }

    @Override
    public int registerRoot(User user) {
        int row = userMapper.registerRoot(user);
        return row;
    }

    @Override
    public List<User> loginWx(User user) {
        List<User> list = userMapper.loginWx(user);
        return list;
    }

    @Override
    public void updateUserInform(User user) {
        userMapper.updateUserInform(user);

    }

    @Override
    public List<User> selectUserPhone(User user) {
        List<User> list = userMapper.selectUserPhone(user);
        return list;
    }
    //设备绑定
    @Override
    public int bingDing(User user) {
        int result = userMapper.bingDing(user);
        return result;
    }

    @Override
    public int selectChouYan(User user) {
        int result = userMapper.selectChouYan(user);
        return result;
    }

    @Override
    public int selectDaHaQ(User user) {
        int result = userMapper.selectDaHaQ(user);
        return result;
    }

    @Override
    public int selectPlay(User user) {
        int result = userMapper.selectPlay(user);
        return result;
    }

    @Override
    public int selectDiTou(User user) {
        int result = userMapper.selectDiTou(user);
        return result;
    }

    @Override
    public int selectEye(User user) {
        int result = userMapper.selectEye(user);
        return result;
    }

}

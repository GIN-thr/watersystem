package com.waterexaminatonsystem.JavaBean;

public class DevData {
    private int id;
    private String devId;
    private String temp;
    private String muddy;
    private String conductivity;
    private String deep;
    private String ph;
    private int page;
    private int size;
    public DevData(){}

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public DevData(int id, String devId, String temp, String muddy, String conductivity, String deep, String ph) {
        this.id = id;
        this.devId = devId;
        this.temp = temp;
        this.muddy = muddy;
        this.conductivity = conductivity;
        this.deep = deep;
        this.ph = ph;
    }

    public String getPh() {
        return ph;
    }

    public void setPh(String ph) {
        this.ph = ph;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDevId() {
        return devId;
    }

    public void setDevId(String devId) {
        this.devId = devId;
    }

    public String getTemp() {
        return temp;
    }

    public void setTemp(String temp) {
        this.temp = temp;
    }

    public String getMuddy() {
        return muddy;
    }

    public void setMuddy(String muddy) {
        this.muddy = muddy;
    }

    public String getConductivity() {
        return conductivity;
    }

    public void setConductivity(String conductivity) {
        this.conductivity = conductivity;
    }

    public String getDeep() {
        return deep;
    }

    public void setDeep(String deep) {
        this.deep = deep;
    }

    @Override
    public String toString() {
        return "DevData{" +
                "size=" + size +
                ", page=" + page +
                '}';
    }
}

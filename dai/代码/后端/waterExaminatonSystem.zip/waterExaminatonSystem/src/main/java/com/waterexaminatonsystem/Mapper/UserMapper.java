package com.waterexaminatonsystem.Mapper;

import com.waterexaminatonsystem.JavaBean.User;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface UserMapper {
    //    用户端
    int login(@Param("user") User user);
    int register(@Param("user")User user);
    int selectPhone(@Param("user")User user);
    //    管理端
    List<User> selectAllUser(@Param("user")User user);
    void deleteUser(@Param("user")User user);
    void updateUser(@Param("user")User user);
    List<User> selectUserName(@Param("user")User user);
    void userUpdatePassword(@Param("user")User user);
    int selectUserCount();
    int registerRoot(@Param("user")User user);

    //微信端
    List<User> loginWx(@Param("user")User user);
    void updateUserInform(@Param("user")User user);
    List<User> selectUserPhone(@Param("user")User user);
    int bingDing(@Param("user")User user);
    int selectChouYan(@Param("user")User user);
    int selectDaHaQ(@Param("user")User user);
    int selectPlay(@Param("user")User user);
    int selectDiTou(@Param("user")User user);
    int selectEye(@Param("user")User user);
}

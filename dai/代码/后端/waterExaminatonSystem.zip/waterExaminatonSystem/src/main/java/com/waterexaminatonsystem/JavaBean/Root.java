package com.waterexaminatonsystem.JavaBean;

public class Root {
    private int id;
    private String username;
    private String password;
    private String role;
    private int page;
    private int size;
    private String registerTime;


    public Root(String registerTime, int size, int page) {
        this.registerTime = registerTime;
        this.size = size;
        this.page = page;
    }

    @Override
    public String toString() {
        return "Root{" +
                "page=" + page +
                ", size=" + size +
                ", registerTime='" + registerTime + '\'' +
                '}';
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public String getRegisterTime() {
        return registerTime;
    }

    public void setRegisterTime(String registerTime) {
        this.registerTime = registerTime;
    }

    public Root(){

    }
    public Root(int id, String username, String password, String role) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.role = role;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

}


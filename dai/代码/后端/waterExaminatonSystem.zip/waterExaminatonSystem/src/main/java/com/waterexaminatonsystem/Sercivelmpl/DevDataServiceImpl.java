package com.waterexaminatonsystem.Sercivelmpl;

import com.waterexaminatonsystem.JavaBean.DevData;
import com.waterexaminatonsystem.Mapper.DevDataMapper;
import com.waterexaminatonsystem.Service.DevDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DevDataServiceImpl implements DevDataService {
    @Autowired
    private DevDataMapper devDataMapper;
    @Override
    public List<DevData> selectAll(DevData devData) {
        List<DevData> list = this.devDataMapper.selectAll(devData);
        return list;
    }

    @Override
    public List<DevData> selectMangaName(DevData devData) {
        List<DevData> list = this.devDataMapper.selectMangaName(devData);
        return list;
    }

    @Override
    public void deleteWork(DevData devData) {
        this.devDataMapper.deleteWork(devData);
    }

    @Override
    public void updateManga(DevData devData) {
        this.devDataMapper.updateManga(devData);
    }

    @Override
    public int selectAllNumber(DevData devData) {
        int number = this.devDataMapper.selectAllNumber(devData);
        return number;
    }

    @Override
    public int selectDevCount() {
        return this.devDataMapper.selectDevCount();
    }


}

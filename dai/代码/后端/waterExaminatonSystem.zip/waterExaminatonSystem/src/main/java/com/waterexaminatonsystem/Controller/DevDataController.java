package com.waterexaminatonsystem.Controller;

import com.waterexaminatonsystem.JavaBean.DevData;
import com.waterexaminatonsystem.Service.DevDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;
@Controller
public class DevDataController {
    @Autowired
    private DevDataService devDataService;
    @RequestMapping("select")
    @ResponseBody
    public List<DevData> selectAll(DevData devData) {
        try {
            int page = devData.getPage();
            int num = (page-1)*Integer.valueOf(String.valueOf(devData.getSize() ));
            System.out.println(devData.getSize() );
            devData.setPage(Integer.valueOf(String.valueOf(num )));
            devData.setSize(Integer.valueOf(String.valueOf(devData.getSize() )));

            List<DevData> list ;
            if(devData.getDevId() != null && !devData.getDevId().equals("")){
                list = devDataService.selectMangaName(devData);
            }
//            else if(devData.getAuthor() != null && !manga.getAuthor().equals("")){
//                list = mangaService.selectMangaAuthor(manga);
//            }
            else {
                list = devDataService.selectAll(devData);
            }

            System.out.println(list);
            return list;
        } catch (NumberFormatException e) {
            // 处理无法转换为整数的情况
            e.printStackTrace();
            return null;
        }
    }

    @RequestMapping("deleteWork")
    @ResponseBody
    public void deleteWork(DevData devData){
        devDataService.deleteWork(devData);

    }

    @RequestMapping("updateManga")
    @ResponseBody
    public void updateManga(DevData devData){
        devDataService.deleteWork(devData);

    }
}

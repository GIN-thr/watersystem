package com.waterexaminatonsystem.Controller;

import com.waterexaminatonsystem.JavaBean.Root;
import com.waterexaminatonsystem.Service.DevDataService;
import com.waterexaminatonsystem.Service.RootService;
import com.waterexaminatonsystem.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.List;

@Controller
public class RootController {
    @Autowired
    private RootService rootService;
    @Autowired
    private DevDataService devDataService;
    @Autowired
    private UserService userService;


    @RequestMapping("/rootLogin")
    @ResponseBody
    public List<Root> rootLogin(Root root) {

        System.out.println("用户名"+root.getUsername());
        System.out.println("密码"+root.getPassword());
        List<Root> list = rootService.rootLogin(root);
        System.out.println(list);
        return list;
    }

    //    管理员注册
    @RequestMapping("/rootRegister")
    @ResponseBody
    public int rootRegister(Root root) {
        System.out.println("用户名"+root.getUsername());
        System.out.println("密码"+root.getPassword());
        System.out.println("密码"+root.getRole());
        int result = 7;
        List<Root> num ;

        num  = rootService.rootLogin(root);
        System.out.println("111"+num);
        if(root.getPassword().isEmpty() ||root.getUsername() == null)
        {
            result = 0;
        } else if (num!=null && num.size()>0) {
            result = 1;

        }
        else
        {
            result = 2;
            rootService.rootRegister(root);
        }
        return result;
    }

    @RequestMapping("rootSelectInform")
    @ResponseBody
    public List<Root> rootSelectInform(Root root) {
        try {
            int page = root.getPage();
            System.out.println(page);
            int num = (page - 1) *root.getSize();
            System.out.println(num);
            root.setSize(Integer.valueOf(String.valueOf(num )));
            List<Root> list;
            if(root.getUsername() != null && !root.getUsername().equals(""))
            {
                System.out.println("查询名字"+root.getUsername());
                list = rootService.selectRootName(root);
                System.out.println(list);
            }
            else
            {
                list = rootService.rootSelectInform(root);
            }
            System.out.println(list);
            return list;
        } catch (NumberFormatException e) {
            // 处理无法转换为整数的情况
            e.printStackTrace();
            return null;
        }
    }
    //管理员删除
    @RequestMapping("rootDelete")
    @ResponseBody
    public void rootDelete(Root root) {
        System.out.println("删除ID"+root.getId());
        rootService.rootDelete(root);

    }
    //    管理员修改
    @RequestMapping("rootUpdate")
    @ResponseBody
    public void rootUpdate(Root root) {
        System.out.println("修改ID"+root.getId());
        System.out.println("修改用户名"+root.getUsername());
        System.out.println("修改角色"+root.getRole());
        rootService.rootUpdate(root);

    }


    @RequestMapping("rootUpdatePassword")
    @ResponseBody
    public void rootUpdatePassword(Root root) {
        System.out.println("修改ID"+root.getId());
        System.out.println("修改管理员密码"+root.getPassword());

        rootService.rootUpdatePassword(root);

    }
//    统计总数

    @RequestMapping("/selectCount2")
    @ResponseBody
    public List<Integer> selectCount() {
        Integer userNum = userService.selectUserCount();
        Integer mangaNum = devDataService.selectDevCount();
        Integer rootNum = rootService.selectRootCount();
        List<Integer> list = new ArrayList<>();
        list.add(userNum);
        list.add(mangaNum);
        list.add(rootNum);
        System.out.println(list);
        return list;

    }

}

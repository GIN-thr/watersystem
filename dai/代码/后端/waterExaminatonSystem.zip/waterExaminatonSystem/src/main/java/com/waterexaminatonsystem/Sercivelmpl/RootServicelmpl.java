package com.waterexaminatonsystem.Sercivelmpl;

import com.waterexaminatonsystem.JavaBean.Root;

import com.waterexaminatonsystem.Mapper.RootMapper;
import com.waterexaminatonsystem.Service.RootService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class RootServicelmpl implements RootService {
    @Autowired
    private RootMapper rootMapper;

    @Override
    public List<Root> rootLogin(Root root) {
        List<Root> list = rootMapper.rootLogin(root);
        return list;
    }
    //管理员注册
    @Override
    public int rootRegister(Root root) {
        int result = rootMapper.rootRegister(root);
        return result;
    }

    @Override
    public List<Root> rootSelectInform(Root root) {
        List<Root> list = rootMapper.rootSelectInform(root);
        return list;
    }
    //删除管理员
    @Override
    public void rootDelete(Root root) {
        rootMapper.rootDelete(root);

    }
    //修改信息
    @Override
    public void rootUpdate(Root root) {
        rootMapper.rootUpdate(root);
    }
    //修改密码
    @Override
    public void rootUpdatePassword(Root root) {
        rootMapper.rootUpdatePassword(root);
    }

    @Override
    public int selectRootCount() {
        int count = rootMapper.selectRootCount();

        return count;
    }

    @Override
    public List<Root> selectRootName(Root root) {
        List<Root> list = rootMapper.selectRootName(root);
        return list;
    }
}

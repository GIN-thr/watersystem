package com.waterexaminatonsystem.Mapper;

import com.waterexaminatonsystem.JavaBean.DevData;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface DevDataMapper {
    List<DevData> selectAll(@Param("devData")DevData devData);
    List<DevData> selectMangaName(@Param("devData")DevData devData);
    void deleteWork(@Param("devData")DevData devData);
    void updateManga(@Param("devData")DevData devData);
    int  selectAllNumber(@Param("devData")DevData devData);

    int selectDevCount();
}

package com.waterexaminatonsystem.Service;

import com.waterexaminatonsystem.JavaBean.Root;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface RootService {
    List<Root> rootLogin(@Param("root")Root root);
    int rootRegister(@Param("root")Root root);
    List<Root> rootSelectInform(@Param("root")Root root);
    void rootDelete(@Param("root")Root root);
    void rootUpdate(@Param("root")Root root);
    void rootUpdatePassword(@Param("root")Root root);
    int selectRootCount();
    List<Root> selectRootName(@Param("root")Root root);


}

package com.waterexaminatonsystem.Controller;

import com.waterexaminatonsystem.JavaBean.User;
import com.waterexaminatonsystem.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@Controller
public class UserController {
    @Autowired
    private UserService userService;

    //用户登录
    @RequestMapping("/login")
    @ResponseBody
    public int login(User user){
        System.out.println(user.getPhone());
        System.out.println(user.getPassword());
        int i = userService.login(user);
        System.out.printf("----"+i);
        return i;
    }
    //    用户注册
    @RequestMapping("/register")
    @ResponseBody
    public int register(User user){

        System.out.println(user.getPhone());
        System.out.println(user.getPassword());
        int number=userService.selectPhone(user);
        System.out.println(number);
        int result=7;

        if(user.getPhone().isEmpty() ||user.getPhone() == null)
        {
            result = 0;
        }
        else if( number != 0 )
        {
            result = 1;
        }
        else {
            int i = userService.register(user);
            result = 2;
        }

        return result;


    }

    //    管理端
    @RequestMapping("/selectAllUser")
    @ResponseBody
    public List<User> selectAllUser(User user){
        try {
            int page = user.getPage();
            int num = (page-1)*6;
            user.setPage(Integer.valueOf(String.valueOf(num )));
            user.setSize(Integer.valueOf(user.getSize()));
            List<User> list ;
            System.out.println(user.getUsername());
            if(user.getUsername() != null && !user.getUsername().equals(""))
            {
                list = userService.selectUserName(user);

            }
            else {
                list = userService.selectAllUser(user);

            }
            System.out.println("查询到的数据"+list);

            return list;
        } catch (NumberFormatException e) {
            // 处理无法转换为整数的情况
            e.printStackTrace();
            return null;
        }
    }


    @RequestMapping("/deleteUser")
    @ResponseBody
    public void deleteUser(User user) {
        System.out.println(user.getId());
        userService.deleteUser(user);

    }

    @RequestMapping("/userUpdatePassword")
    @ResponseBody
    public void userUpdatePassword(User user) {
        System.out.println("用户ID"+user.getId());
        System.out.println("用户新密码"+user.getPassword());
        userService.userUpdatePassword(user);
    }

    @RequestMapping("updateUser")
    @ResponseBody
    public void updateUser(User user) {
        System.out.println("修改用户名"+user.getUsername());
        userService.updateUser(user);

    }
    //增加用户
    @RequestMapping("registerRoot")
    @ResponseBody
    public int registerRoot(User user) {

        System.out.println("增加用户手机号："+user.getPhone());
        int num=userService.selectPhone(user);
        int number =9;
        if(num!=0)
        {
            number = 0;
        }
        else {
            number = userService.registerRoot(user);
        }
        return number;
    }
    @RequestMapping("/selectUserName")
    @ResponseBody
    public List<User> selectUserName(User user) {
        System.out.println(user.getUsername());
        List<User> list = userService.selectUserName(user);
        System.out.println(list);
        return list;

    }

    //小程序
    @RequestMapping("/loginWx")
    @ResponseBody
    public List<User> loginWx(User user) {
        System.out.println(user.getUsername());
        List<User> list = userService.loginWx(user);
        System.out.println(list);
        return list;

    }

    @RequestMapping("/codeWX")
    @ResponseBody
    public String codeWX() {
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        StringBuilder sb = new StringBuilder();

        Random random = new Random();
        for (int i = 0; i < 4; i++) {
            int randomIndex = random.nextInt(characters.length());
            sb.append(characters.charAt(randomIndex));
        }
        String code = sb.toString();
        System.out.println(code);
        return code;

    }

    @RequestMapping("/bingDing")
    @ResponseBody
    public int bingDing(User user) {
        int i = userService.bingDing(user);
        System.out.println(i);

        return i;
    }
    @RequestMapping("/selectCount")
    @ResponseBody
    public List<Integer> selectCount(User user) {
        int num1 = userService.selectChouYan(user);
        int num2 = userService.selectPlay(user);
        int num3 = userService.selectEye(user);
        int num4 = userService.selectDaHaQ(user);
        int num5 = userService.selectDiTou(user);
        List<Integer> list = new ArrayList<Integer>();
        list.add(num1);
        list.add(num2);
        list.add(num3);
        list.add(num4);
        list.add(num5);
        return list;
    }
}

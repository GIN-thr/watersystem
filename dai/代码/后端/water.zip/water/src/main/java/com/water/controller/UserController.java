package com.water.controller;

import com.water.javaBean.Food;
import com.water.javaBean.Order;
import com.water.javaBean.User;
import com.water.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Controller
@RestController
public class UserController {
    @Autowired
    private UserService US;

    @RequestMapping("/login")
    @CrossOrigin
    public String Login(@RequestParam("username") String username, @RequestParam("password") String password){
        User user = new User(username,password,null);
        return US.Login(user);
    }

    @RequestMapping("/register")
    @CrossOrigin
    public String Register(@RequestParam("username") String username,@RequestParam("password") String password,@RequestParam("touxiang") String touxiang){
        User user = new User(username, password,touxiang);
        return US.Register(user);
    }


    @RequestMapping("/checkFoods")
    @CrossOrigin
    public List<Food> CheckFoods(@RequestParam("classs") String classs){
        return US.CheckFoods(classs);
    }

    @RequestMapping("/reset")
    @CrossOrigin
    public String Reset(@RequestParam("username") String username,@RequestParam("password") String password){
        User user = new User(username, password,null);
        return US.Reset(user);
    }

    @RequestMapping("/getMyInfo")
    @CrossOrigin
    public List<User> GetMyInfo(@RequestParam("username") String username){
        return US.GetMyInfo(username);
    }

    @RequestMapping("/saveMyInfo")
    @CrossOrigin
    public String SaveMyInfo(@RequestParam("username") String username,@RequestParam("touxiang") String touxiang){
        User user = new User(username,null,touxiang);
        return US.SaveMyInfo(user);
    }
    @RequestMapping("/getOrderId")
    @CrossOrigin
    public List<Order> GetOrderId(@RequestParam("username") String username){
        return US.GetOrderId(username);
    }
    @RequestMapping("/getOrderInfo")
    @CrossOrigin
    public List<Food> GetOrderInfo(@RequestParam("id") int id){
        return US.GetOrderInfo(id);
    }
    @RequestMapping("/saveOrder")
    @CrossOrigin
    public String SaveOrder(@RequestParam("username") String username,@RequestParam("itemId") String itemId){
        return US.SaveOrder(username, itemId);
    }
    @RequestMapping("/deleteOrder")
    @CrossOrigin
    public String DeleteOrder(@RequestParam("username") String username,@RequestParam("itemId") String itemId){
        return US.DeleteOrder(username, itemId);
    }
}

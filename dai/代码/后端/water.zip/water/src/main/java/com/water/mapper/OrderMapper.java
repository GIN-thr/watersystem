package com.water.mapper;

import com.water.javaBean.Food;
import com.water.javaBean.Order;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public interface OrderMapper {

    String SaveOrder(String username, String itemId);

    List<Order> GetOrderId(String username);

    void DeleteOrder(String username, String itemId);
}

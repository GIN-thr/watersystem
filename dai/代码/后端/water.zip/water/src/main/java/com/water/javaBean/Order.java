package com.water.javaBean;

public class Order {
    private int id;
    private String username;
    private String itemId;

    public Order(int id, String username, String itemId) {
        this.id = id;
        this.username = username;
        this.itemId = itemId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getItemId() {
        return itemId;
    }

    public void setItemId(String itemId) {
        this.itemId = itemId;
    }
}

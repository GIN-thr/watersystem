package com.water.mapper;

import com.water.javaBean.User;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public interface UserMapper {

    int Login(@Param("user") User user);

    int Register(@Param("user") User user);

    int Reset(@Param("user") User user);

    List<User> GetMyInfo(String username);

    int SaveMyInfo(@Param("user") User user);
}

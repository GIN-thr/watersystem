package com.water.service;

import com.water.javaBean.Food;
import com.water.javaBean.Order;
import com.water.javaBean.User;

import java.util.List;

public interface UserService {

    String Login(User user);

    String Register(User user);

    List<Food> CheckFoods(String classs);

    String Reset(User user);

    List<User> GetMyInfo(String username);

    String SaveMyInfo(User user);

    String SaveOrder(String username, String itemId);

    List<Order> GetOrderId(String username);

    List<Food> GetOrderInfo(int id);

    String DeleteOrder(String username, String itemId);
}

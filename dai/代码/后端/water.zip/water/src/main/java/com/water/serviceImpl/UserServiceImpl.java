package com.water.serviceImpl;

import com.water.javaBean.Food;
import com.water.javaBean.Order;
import com.water.javaBean.User;
import com.water.mapper.FoodMapper;
import com.water.mapper.OrderMapper;
import com.water.mapper.UserMapper;
import com.water.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserMapper UM;
    @Autowired
    private FoodMapper FM;
    @Autowired
    private OrderMapper OM;

    @Override
    public String Login(User user) {
        int i = UM.Login(user);
        if(i == 0){
            return "用户名或密码错误！";
        }else{
            return "ok";
        }
    }

    @Override
    public String Register(User user) {
        UM.Register(user);
        return "ok";
    }

    @Override
    public List<Food> CheckFoods(String classs) {
        return FM.CheckFoods(classs);
    }

    @Override
    public String Reset(User user) {
        UM.Reset(user);
        return "ok";
    }

    @Override
    public List<User> GetMyInfo(String username) {
        return UM.GetMyInfo(username);
    }

    @Override
    public String SaveMyInfo(User user) {
        UM.SaveMyInfo(user);
        return "ok";
    }

    @Override
    public String SaveOrder(String username, String itemId) {
        OM.SaveOrder(username, itemId);
        return "ok";
    }

    @Override
    public List<Order> GetOrderId(String username) {
        return OM.GetOrderId(username);
    }

    @Override
    public List<Food> GetOrderInfo(int id) {
        return FM.GetOrderInfo(id);
    }

    @Override
    public String DeleteOrder(String username, String itemId) {
        OM.DeleteOrder(username, itemId);
        return "ok";
    }
}

package com.water.javaBean;

public class Food {
    private int id;
    private String name;
    private String price;
    private String src;
    private String classs;

    public Food(int id, String name, String price, String src, String classs) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.src = src;
        this.classs = classs;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getSrc() {
        return src;
    }

    public void setSrc(String src) {
        this.src = src;
    }

    public String getClasss() {
        return classs;
    }

    public void setClasss(String classs) {
        this.classs = classs;
    }
}

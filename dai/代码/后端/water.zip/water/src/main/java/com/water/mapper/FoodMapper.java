package com.water.mapper;

import com.water.javaBean.Food;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public interface FoodMapper {
    List<Food> CheckFoods(String classs);

    List<Food> GetOrderInfo(int id);
}
